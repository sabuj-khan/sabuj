<?php
/*
Plugin Name: Standard Employee Info
Plugin URI: https://sabuj.mokam24.com/demo/plugins/
Author: Mohammad Sabuj Khan
Author URI: https://sabuj.mokam24.com
Version: 1.0.0
Description: The plugin is being used to add the employee's personal information. Using this pugin we can add personal information of student, teacher, doctors, employee etc. You can add and show the employee's all information using this standard employee info plugin
Tags: sabuj, personal, sabuj info, personal info, info, information, employee, employee info, employee,s information
Text Domain: employee_info
Domain Path: /languages
*/

class EmployeeInfo {
    public function __construct(){
        add_action('plugins_loaded', array( $this, 'employee_info_text_domain_setup'));
        add_action('init', array( $this, 'employee_info_register_post_type'));
        add_action('add_meta_boxes', array($this, 'employee_info_meta_information'));
        add_action('save_post', array($this, 'employee_info_meta_save_post'));
        add_action('admin_enqueue_scripts', array($this, 'employee_info_files_scripting'));
        add_action('wp_enqueue_scripts', array($this, 'employee_info_front_files_scripting'));
        add_shortcode('employee-list', array($this, 'employee_info_callback_output'));
    }

    public function employee_info_text_domain_setup(){
        load_plugin_textdomain( 'employee_info', false, plugin_dir_path(__FILE__).'/languages' );
    }

    public function employee_info_files_scripting(){
        wp_enqueue_style('si-custom-css', plugin_dir_url(__FILE__)."/assets/css/custom.css", null, time());
        wp_enqueue_scripts('jquery-ui-tabs');
        wp_enqueue_script('ei-custom-js', plugin_dir_url(__FILE__)."/assets/js/custom.js", array('jquery', 'jquery-ui-tabs'), null, true);
    }

    public function employee_info_front_files_scripting(){
        wp_enqueue_style('si-custom-css', plugin_dir_url(__FILE__)."/assets/css/front.css", null, time());
    }

    public function employee_info_register_post_type(){
        $labels = array(
            'name'               => _x( 'Employees', 'Post type general name', 'employee_info' ),
            'singular_name'      => _x( 'Employee', 'Post type singular name', 'employee_info' ),
            'menu_name'          => _x( 'Employees', 'Admin Menu text', 'employee_info' ),
            'name_admin_bar'     => _x( 'Employee', 'Add New on Toolbar', 'employee_info' ),
            'add_new'            => __( 'Add New Employee', 'employee_info' ),
            'add_new_item'       => __( 'Add New Employee', 'employee_info' ),
            'new_item'           => __( 'New Employee', 'employee_info' ),
            'edit_item'          => __( 'Edit Employee', 'employee_info' ),
            'view_item'          => __( 'View Employee', 'employee_info' ),
            'all_items'          => __( 'All Employees', 'employee_info' ),
        );

        $arguments = array(
            'labels'             => $labels,
            'description'        => 'Employees custom post type.',
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'Employee' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => true,
            'menu_position'      => NULL,
            'menu_icon'			 => 'dashicons-businessperson',
            'supports'           => array( 'title', 'editor', 'thumbnail' ),
            'show_in_rest'       => true
         );

         register_post_type( 'employee-info', $arguments );


         $label = array(
            'name'			=> __( 'Employee Types', 'employee_info' ),
			'singular_name' => __( 'Employee Type', 'employee_info' ),
			'add_new_item'	=> __( 'Add New Type', 'employee_info' ),
			'add_new'		=> __( 'Add New Type', 'employee_info' ),
			'new_item'      => __( 'New Type', 'employee_info' ),
			'edit_item'		=> __( 'Edit Type', 'employee_info' ),
        );

        $argu = array(
            'labels'             => $label,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'query_var'          => true,
            'hierarchical'       => true,
            'rewrite'            => array('slug' => 'type'),
    );

        register_taxonomy( 'emp-info-type', 'employee-info', $argu );
    }

    // meta information

    public function employee_info_meta_information(){
        add_meta_box('add-employee-info', 'Employee Additional Information', array($this, 'individual_information'), 'employee-info');
    }
    public function individual_information(){

        $v_father = get_post_meta(get_the_id(), '_employee-f-name', true);
        $v_mother = get_post_meta(get_the_id(), '_employee-m-name', true);
        $v_gender = get_post_meta(get_the_id(), '_employee-gender', true);
        $v_age    = get_post_meta(get_the_id(), '_employee-age', true);
        $v_ssc    = get_post_meta(get_the_id(), '_employee-ssc', true);
        $v_designation    = get_post_meta(get_the_id(), '_employee-designation', true);
        $v_experience    = get_post_meta(get_the_id(), '_employee-experience', true);
        ?>
            <div id="tabs">
                <ul>
                    <li><a href="#personal">Personal Information</a></li>
                    <li><a href="#gender">Employee's Gender</a></li>
                    <li><a href="#age">Employee's Age</a></li>
                    <li><a href="#designation">Designation</a></li>
                    <li><a href="#academic">Academic Qualification</a></li>
                    <li><a href="#experience">Experience</a></li>
                </ul>
                <div id="personal">
                    <p><label for="father">Father's Name</label></p>
                    <p><input type="text" name="father" value="<?php echo $v_father; ?>" id="father"></p>
                    <p><label for="mother">Mother's Name</label></p>
                    <p><input type="text" name="mother" value="<?php echo $v_mother; ?>" id="mother"></p>
                </div>
                <div id="gender">
                    <p>
                        <input type="radio" name="gender" id="male" value="male" <?php if( $v_gender == 'male'){ echo "checked = 'checked'"; } ?>>
                        <label for="male">Male</label>
                     </p>
                     <p>
                        <input type="radio" name="gender" id="female" value="female" <?php if( $v_gender == 'female'){ echo "checked = 'checked'"; } ?>>
                        <label for="female">Female</label>
                     </p>                   
                </div>

                <div id="age">
                    <p><label for="age">Employee's Age</label></p>
                    <p><input type="number" name="age" value="<?php echo $v_age;  ?>" id="age"></p>
                </div>



                <div id="academic">
                    <p><label for="ssc">Year of The SSC</label></p>
                    <p><input type="number" name="ssc" value="<?php echo $v_ssc;  ?>" id="ssc"></p>
                </div>

                <div id="designation">
                    <p><label for="designation">Designation </label></p>
                    <p><input type="text" name="designation" id="designation" value="<?php echo $v_designation; ?>"></p>
                </div>

                <div id="experience">
                    <p><label for="experience">Experience </label></p>
                    <p><input type="text" name="experience" id="experience" value="<?php echo $v_experience; ?>"></p>
                </div>
            </div>


        <?php
    }

    public function employee_info_meta_save_post($post_id){

        $fname = isset($_POST['father']) ? $_POST['father'] : ''; 
        $mname = isset($_POST['mother']) ? $_POST['mother'] : ''; 
        $gender = isset($_POST['gender']) ? $_POST['gender'] : ''; 
        $age = isset($_POST['age']) ? $_POST['age'] : ''; 
        $ssc = isset($_POST['ssc']) ? $_POST['ssc'] : ''; 
        $designation = isset($_POST['designation']) ? $_POST['designation'] : ''; 
        $experience = isset($_POST['experience']) ? $_POST['experience'] : ''; 

        update_post_meta($post_id, '_employee-f-name', $fname);
        update_post_meta($post_id, '_employee-m-name', $mname);
        update_post_meta($post_id, '_employee-gender', $gender);
        update_post_meta($post_id, '_employee-age', $age);
        update_post_meta($post_id, '_employee-ssc', $ssc);
        update_post_meta($post_id, '_employee-designation', $designation);
        update_post_meta($post_id, '_employee-experience', $experience);
    }

    public function employee_info_callback_output( $attr, $content){
        ob_start();

        $employee_sort = shortcode_atts( array(
                'count'     => -1,
        ), $attr );

        extract($employee_sort);
        
        ?>
        <div class="employee-list">

        <?php 
            $currentpage = get_query_var('paged') ? get_query_var('paged') : 1;
            $list_employee = new WP_Query(array(
                'post_type'     => 'employee-info',
                'posts_per_page'    => $count,
                'paged'				=> $currentpage
            ));
        while( $list_employee->have_posts() ) : $list_employee->the_post(); ?>
            <article class="employee">
                <div class="employee-image">
                    <div class="ename">
                        <h3><?php the_title(); ?></h3>
                    </div>
                    <?php the_post_thumbnail('medium'); ?>
                </div>
                <div class="employee-detail">
                    
                    <div class="odetail">
                        <p><strong>Designation: </strong><?php echo get_post_meta(get_the_id(), '_employee-designation', true); ?></p>

                        <p><strong>Mother's Name: </strong><?php echo get_post_meta(get_the_id(), '_employee-f-name', true); ?></p>

                        <p><strong>Father's Name: </strong><?php echo get_post_meta(get_the_id(), '_employee-m-name', true); ?></p>

                        <p><strong>Father's Name: </strong><?php echo get_post_meta(get_the_id(), '_employee-m-name', true); ?></p>

                        <p><strong>Gender: </strong><?php echo get_post_meta(get_the_id(), '_employee-gender', true); ?></p>

                        <p><strong>Age: </strong><?php echo get_post_meta(get_the_id(), '_employee-age', true); ?></p>

                        <p><strong>Academic Qualification: </strong><?php echo get_post_meta(get_the_id(), '_employee-ssc', true); ?></p>

                        <p><strong>Experience: </strong><?php echo get_post_meta(get_the_id(), '_employee-experience', true); ?></p>

                        <p><strong>Employee's Level: </strong><?php 
                            $employeess = get_the_terms(get_the_id(), 'emp-info-type' );

                            foreach( $employeess as $employe ){
                                echo $employe->name;
                            }
                    
                        ?></p>

                        <p><strong>About Employee: </strong><?php the_content(); ?></p>

                    </div>
                </div>
            </article>
            <hr>

            <?php endwhile; ?>

            <?php 
	
	$maxpage	 = $list_employee->max_num_pages;

        echo paginate_links(array(
            'current'		=> $currentpage,
            'total'			=> $maxpage,
            'show_all'		=> true,
            'prev_text'     => 'Age',
            'next_text'     => 'Pore',
        )); ?>

        </div>


        <?php return ob_get_clean();
    }
}

$employee_info = new EmployeeInfo();

