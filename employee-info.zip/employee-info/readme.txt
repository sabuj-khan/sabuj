=== Standard Employee Info ===
Contributors: shobujkhan
Tags: sabuj, personal, sabuj info, personal info, info, information, employee, employee info, employee,s information
Requires at least: 4.7
Tested up to: 5.4
Stable tag: 4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

To add especially all the official information of an employee 

== Description ==

The plugin is being used to add the employee's personal information. Using this plugin we can add the personal information of students, teachers, doctors, employees, etc. You 

can add and show the employee's all information using this standard employee info plugin


== Frequently Asked Questions ==

= Can the plugin be used with both classic editor and block editor? =

Yes, this plugin is compatible with all editors.

= Is it possible to edit the plugin root file? =

Of course, you can edit the files as you need.


